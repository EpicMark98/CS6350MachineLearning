#!/bin/bash

echo "Running python script..."
python3 DecisionTree.py
