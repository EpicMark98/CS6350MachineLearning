#!/bin/bash

echo "Running python script..."
python3 Perceptron.py
