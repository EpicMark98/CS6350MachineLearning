#!/bin/bash

echo "Running python script..."
python3 SVM.py
